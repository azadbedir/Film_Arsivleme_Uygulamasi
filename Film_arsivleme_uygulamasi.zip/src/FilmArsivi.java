import java.util.*;

// film ekleme, silme, listeleme ve filtreleme işlemleri

public class FilmArsivi {

    // Kapsülleme (Encapsulation):
    // Filmler listesi dışarıya doğrudan açılmıyor.
    private List<Film> filmler = new ArrayList<>();

    // Film ekleme metodu
    public void filmEkle(Film film) {
        filmler.add(film);
        System.out.println("✅ Film eklendi: " + film.getAd());
    }

    // Film silme metodu
    public void filmSil(String ad) {
        boolean silindi = filmler.removeIf(f -> f.getAd().equalsIgnoreCase(ad));
        if (silindi)
            System.out.println("🗑️ Film silindi: " + ad);
        else
            System.out.println("⚠️ Film bulunamadı!");
            System.out.println("lütfen başka bir film için arama yapın 😊");
    }

    // Filmi arşive alma metodu
    public void arsiveAl(String ad) {
        for (Film f : filmler) {
            if (f.getAd().equalsIgnoreCase(ad)) {
                f.setArsivde(true);
                System.out.println("📦 Arşive alındı: " + ad);
                return;
            }
        }
        System.out.println("⚠️ Film bulunamadı!");
    }

    // Tüm filmleri listeleme
    public void listele() {
        if (filmler.isEmpty()) {
            System.out.println("❌ Henüz film yok.");
            return;
        }
        // Çok biçimlilik örneği:
        // Her Film nesnesi kendi bilgileriGoster metodunu çağırır.
        for (Film f : filmler)
            f.bilgileriGoster();
    }

    // Türüne göre filtreleme
    public void filtreleTur(String tur) {
        filmler.stream()
                .filter(f -> f.getTur().equalsIgnoreCase(tur))
                .forEach(Film::bilgileriGoster);
    }

    // Yılına göre filtreleme
    public void filtreleYil(int yil) {
        filmler.stream()
                .filter(f -> f.getYil() == yil)
                .forEach(Film::bilgileriGoster);
    }

    // Puanına göre filtreleme
    public void filtrelePuan(double minPuan) {
        filmler.stream()
                .filter(f -> f.getPuan() >= minPuan)
                .forEach(Film::bilgileriGoster);
    }
}
