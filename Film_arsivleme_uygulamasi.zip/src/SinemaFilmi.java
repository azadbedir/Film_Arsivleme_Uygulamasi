// Bu sınıf, Film soyut sınıfından türemiştir (Inheritance).
// Film sınıfındaki soyut metodu (bilgileriGoster) kendine özgü şekilde uygular.
// Bu durum Çok Biçimlilik (Polymorphism) örneğidir.

public class SinemaFilmi extends Film {
    private String yonetmen;

    // Alt sınıfın kendi yapıcısı, üst sınıfın yapıcısını (super) çağırıyor.
    public SinemaFilmi(String ad, String tur, int yil, double puan, String yonetmen) {
        super(ad, tur, yil, puan); // üst sınıfın constructor'ı
        this.yonetmen = yonetmen;
    }

    // Polymorphism (Çok Biçimlilik):
    // Üst sınıftaki soyut metodu burada kendi tarzıyla gerçekleştiriyor.
    @Override
    public void bilgileriGoster() {
        System.out.println("🎬 Film: " + getAd() +
                " | Tür: " + getTur() +
                " | Yıl: " + getYil() +
                " | Puan: " + getPuan() +
                " | Yönetmen: " + yonetmen +
                (isArsivde() ? " (Arşivde)" : ""));
    }
}
