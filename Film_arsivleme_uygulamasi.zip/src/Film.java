// Soyut Sınıf (Abstract Class)

/*
 * Bu sınıf film kavramının temel özelliklerini tanımlar.
 * Soyut sınıf olması, alt sınıfların (örneğin SinemaFilmi)
 * bu yapıyı miras alarak kendine özgü davranışlar eklemesini sağlar.
 * (Abstraction - Soyutlama)
 */
public abstract class Film {

    // Kapsülleme (Encapsulation) örneği:
    // Alanlar private, dışarıdan erişim sadece getter/setter ile mümkün.
    private String ad;
    private String tur;
    private int yil;
    private double puan;
    private boolean arsivde;

    // Yapıcı (constructor)
    public Film(String ad, String tur, int yil, double puan) {
        this.ad = ad;
        this.tur = tur;
        this.yil = yil;
        this.puan = puan;
        this.arsivde = false; // başlangıçta film arşivde değil
    }

    // Getter ve Setter metodları (Encapsulation örneği)
    public String getAd() { return ad; }
    public String getTur() { return tur; }
    public int getYil() { return yil; }
    public double getPuan() { return puan; }
    public boolean isArsivde() { return arsivde; }
    public void setArsivde(boolean arsivde) { this.arsivde = arsivde; }

    // Soyut metot (Abstract Method):
    // Alt sınıflar bu metodu kendi tarzlarına göre yeniden tanımlar.
    public abstract void bilgileriGoster();
}
