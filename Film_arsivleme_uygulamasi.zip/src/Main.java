import java.util.Scanner;

///*
// * Bu sınıf uygulamanın başlangıç noktasıdır.
// * Konsol arayüzü üzerinden kullanıcıyla etkileşim sağlar.
// * Kullanıcı işlemleri FilmArsivi sınıfı üzerinden yapılır.
// */
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        FilmArsivi arsiv = new FilmArsivi(); // Nesne oluşturma

        while (true) {
            // Kullanıcı menüsü
            System.out.println("\n🎞️ === Film Arşivleme Uygulaması ===");
            System.out.println("1. Film Ekle");
            System.out.println("2. Film Sil");
            System.out.println("3. Filmleri Listele");
            System.out.println("4. Arşive Al");
            System.out.println("5. Türüne Göre Filtrele");
            System.out.println("6. Yılına Göre Filtrele");
            System.out.println("7. Puana Göre Filtrele");
            System.out.println("0. Çıkış");
            System.out.print("Seçiminiz: ");

            int secim = scanner.nextInt();
            scanner.nextLine(); // buffer temizleme

            // Kullanıcı seçimlerine göre işlem yapılıyor
            switch (secim) {
                case 1:
                    System.out.print("Film adı: ");
                    String ad = scanner.nextLine();
                    System.out.print("Tür: ");
                    String tur = scanner.nextLine();
                    System.out.print("Yıl: ");
                    int yil = scanner.nextInt();
                    System.out.print("Puan: ");
                    double puan = scanner.nextDouble();
                    scanner.nextLine(); // buffer temizleme
                    System.out.print("Yönetmen: ");
                    String yonetmen = scanner.nextLine();

                    // Kalıtım + Polymorphism:
                    // Film tipinde SinemaFilmi nesnesi oluşturuluyor.
                    arsiv.filmEkle(new SinemaFilmi(ad, tur, yil, puan, yonetmen));
                    break;

                case 2:
                    System.out.print("Silinecek film adı: ");
                    arsiv.filmSil(scanner.nextLine());
                    break;

                case 3:
                    arsiv.listele();
                    break;

                case 4:
                    System.out.print("Arşive alınacak film adı: ");
                    arsiv.arsiveAl(scanner.nextLine());
                    break;

                case 5:
                    System.out.print("Tür: ");
                    arsiv.filtreleTur(scanner.nextLine());
                    break;

                case 6:
                    System.out.print("Yıl: ");
                    arsiv.filtreleYil(scanner.nextInt());
                    break;

                case 7:
                    System.out.print("Minimum puan: ");
                    arsiv.filtrelePuan(scanner.nextDouble());
                    break;

                case 0:
                    System.out.println("👋 Programdan çıkılıyor...");
                    return;

                default:
                    System.out.println("⚠️ Geçersiz seçim! ");
            }
        }
    }
}
